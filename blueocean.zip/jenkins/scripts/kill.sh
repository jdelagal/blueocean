docker rm toolkit_running
