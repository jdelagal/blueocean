#!/usr/bin/env sh
apic login