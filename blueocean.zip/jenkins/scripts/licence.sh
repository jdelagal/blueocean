#!/usr/bin/env sh
apic -h
